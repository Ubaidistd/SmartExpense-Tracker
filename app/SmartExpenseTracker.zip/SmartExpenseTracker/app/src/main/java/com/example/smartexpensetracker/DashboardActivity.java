package com.example.smartexpensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.text.NumberFormat;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    Button openExpenseBtn;
    Button historyBtn;
    Button saveSalaryBtn;
    MaterialButton logoutBtn;
    MaterialButton logoutBtnBottom;
    TextInputEditText salaryInput;
    TextView userGreetingText;
    TextView monthlySalaryText;
    TextView totalExpensesText;
    TextView remainingBalanceText;
    TextView budgetUsedText;
    TextView budgetStatusText;
    LinearProgressIndicator budgetProgressBar;
    ExpenseRepository repository;

    private double monthlySalary = 0;
    private double totalExpenses = 0;
    private final NumberFormat currencyFormat = NumberFormat.getNumberInstance(Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        try {
            repository = new ExpenseRepository();
        } catch (IllegalStateException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        View heroCard = findViewById(R.id.card3d);
        View budgetCard = findViewById(R.id.card3dSecondary);
        View content = findViewById(R.id.dashboardContent);

        Ui3DHelper.applyScreenEntrance(heroCard);

        budgetCard.setAlpha(0f);
        budgetCard.setTranslationY(40f);
        budgetCard.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(200)
                .setDuration(500)
                .start();

        content.setAlpha(0f);
        content.animate().alpha(1f).setDuration(400).start();

        userGreetingText = findViewById(R.id.userGreetingText);
        salaryInput = findViewById(R.id.salaryInput);
        saveSalaryBtn = findViewById(R.id.saveSalaryBtn);
        monthlySalaryText = findViewById(R.id.monthlySalaryText);
        totalExpensesText = findViewById(R.id.totalExpensesText);
        remainingBalanceText = findViewById(R.id.remainingBalanceText);
        budgetUsedText = findViewById(R.id.budgetUsedText);
        budgetStatusText = findViewById(R.id.budgetStatusText);
        budgetProgressBar = findViewById(R.id.budgetProgressBar);
        openExpenseBtn = findViewById(R.id.addExpenseBtn);
        historyBtn = findViewById(R.id.historyBtn);
        logoutBtn = findViewById(R.id.logoutBtn);
        logoutBtnBottom = findViewById(R.id.logoutBtnBottom);

        setupUserGreeting();
        Ui3DHelper.applyButtonPress3D(openExpenseBtn);
        Ui3DHelper.applyButtonPress3D(historyBtn);

        saveSalaryBtn.setOnClickListener(v -> saveMonthlySalary());

        openExpenseBtn.setOnClickListener(v -> openAddExpenseScreen(false));

        historyBtn.setOnClickListener(v -> openAddExpenseScreen(true));

        View.OnClickListener logoutListener = v -> performLogout();
        logoutBtn.setOnClickListener(logoutListener);
        logoutBtnBottom.setOnClickListener(logoutListener);

        updateSummary();
    }

    private void openAddExpenseScreen(boolean focusHistory) {
        Intent intent = new Intent(DashboardActivity.this, AddExpenseActivity.class);
        intent.putExtra(AddExpenseActivity.EXTRA_FOCUS_HISTORY, focusHistory);
        startActivity(intent);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void performLogout() {
        if (repository != null) {
            repository.removeSalaryListener();
            repository.removeTotalListener();
        }
        Toast.makeText(this, R.string.logout_success, Toast.LENGTH_SHORT).show();
        AuthNavigator.logout(this);
    }

    private void setupUserGreeting() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            userGreetingText.setText("Guest");
            return;
        }

        String email = user.getEmail();
        if (email != null && email.contains("@")) {
            String name = email.substring(0, email.indexOf('@'));
            if (!name.isEmpty()) {
                name = name.substring(0, 1).toUpperCase(Locale.getDefault()) + name.substring(1);
            }
            userGreetingText.setText(name);
        } else {
            userGreetingText.setText("User");
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        loadSalaryFromDatabase();
        loadExpensesFromDatabase();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (repository != null) {
            repository.removeSalaryListener();
            repository.removeTotalListener();
        }
    }

    private void saveMonthlySalary() {
        String salaryText = salaryInput.getText() != null
                ? salaryInput.getText().toString().trim()
                : "";

        if (salaryText.isEmpty()) {
            Toast.makeText(this, "Enter your monthly salary", Toast.LENGTH_SHORT).show();
            return;
        }

        double salary;
        try {
            salary = Double.parseDouble(salaryText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter a valid salary amount", Toast.LENGTH_SHORT).show();
            return;
        }

        if (salary <= 0) {
            Toast.makeText(this, "Salary must be greater than 0", Toast.LENGTH_SHORT).show();
            return;
        }

        saveSalaryBtn.setEnabled(false);
        repository.saveMonthlySalary(salary, new ExpenseRepository.SaveListener() {
            @Override
            public void onSuccess() {
                saveSalaryBtn.setEnabled(true);
                Toast.makeText(DashboardActivity.this, "Salary updated", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onFailure(String message) {
                saveSalaryBtn.setEnabled(true);
                Toast.makeText(DashboardActivity.this,
                        "Save failed: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void loadSalaryFromDatabase() {
        repository.listenForSalary(new ExpenseRepository.SalaryListener() {
            @Override
            public void onSalaryLoaded(double salary) {
                monthlySalary = salary;
                if (salary > 0 && salaryInput.getText() != null
                        && salaryInput.getText().toString().trim().isEmpty()) {
                    salaryInput.setText(formatAmount(salary));
                }
                updateSummary();
            }

            @Override
            public void onLoadFailed(String message) {
                Toast.makeText(DashboardActivity.this,
                        "Could not load salary: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void loadExpensesFromDatabase() {
        repository.listenForTotal(new ExpenseRepository.TotalListener() {
            @Override
            public void onTotalCalculated(double total) {
                totalExpenses = total;
                updateSummary();
            }

            @Override
            public void onLoadFailed(String message) {
                Toast.makeText(DashboardActivity.this,
                        "Could not load expenses: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void updateSummary() {
        monthlySalaryText.setText(formatCurrency(monthlySalary));
        totalExpensesText.setText(formatCurrency(totalExpenses));

        double remaining = monthlySalary - totalExpenses;
        remainingBalanceText.setText(formatCurrency(remaining));

        int remainingColor = remaining >= 0
                ? R.color.white
                : R.color.negative_balance;
        remainingBalanceText.setTextColor(ContextCompat.getColor(this, remainingColor));

        int percent = 0;
        if (monthlySalary > 0) {
            percent = (int) Math.min(100, Math.round((totalExpenses / monthlySalary) * 100));
        }
        budgetProgressBar.setProgress(percent, true);
        budgetUsedText.setText(getString(R.string.budget_used_format, percent));

        updateBudgetStatus(percent, remaining);
        updateProgressColor(percent);
    }

    private void updateBudgetStatus(int percent, double remaining) {
        if (monthlySalary <= 0) {
            budgetStatusText.setText(R.string.salary_settings_hint);
            budgetStatusText.setTextColor(ContextCompat.getColor(this, R.color.text_on_dark_muted));
            return;
        }

        if (remaining < 0) {
            budgetStatusText.setText(R.string.budget_over);
            budgetStatusText.setTextColor(ContextCompat.getColor(this, R.color.negative_balance));
        } else if (percent >= 80) {
            budgetStatusText.setText(R.string.budget_warning);
            budgetStatusText.setTextColor(ContextCompat.getColor(this, R.color.accent_gold));
        } else {
            budgetStatusText.setText(R.string.budget_safe);
            budgetStatusText.setTextColor(ContextCompat.getColor(this, R.color.accent_gold));
        }
    }

    private void updateProgressColor(int percent) {
        int colorRes;
        if (percent >= 100) {
            colorRes = R.color.stat_expense_text;
        } else if (percent >= 80) {
            colorRes = R.color.accent_gold;
        } else {
            colorRes = R.color.primary_green_light;
        }
        budgetProgressBar.setIndicatorColor(ContextCompat.getColor(this, colorRes));
    }

    private String formatCurrency(double amount) {
        return getString(R.string.currency_prefix) + " " + formatAmount(amount);
    }

    private String formatAmount(double amount) {
        if (amount == Math.floor(amount)) {
            return currencyFormat.format((long) amount);
        }
        return currencyFormat.format(amount);
    }
}
