package com.example.smartexpensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class AddExpenseActivity extends AppCompatActivity {

    public static final String EXTRA_FOCUS_HISTORY = "extra_focus_history";

    EditText category, note, amount;
    Button addBtn;
    MaterialButton backBtn;
    RecyclerView recyclerView;
    TextView expenseCountText;
    TextView listTotalText;
    TextView historyCountBadge;
    LinearLayout emptyStateLayout;
    MaterialCardView historyCard;

    ArrayList<ExpenseModel> list;
    ExpenseAdapter adapter;
    ExpenseRepository repository;
    final Map<String, Integer> idToIndex = new HashMap<>();
    final NumberFormat currencyFormat = NumberFormat.getNumberInstance(Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_expense);

        if (FirebaseAuth.getInstance().getCurrentUser() == null) {
            Toast.makeText(this, "Please login first", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        try {
            repository = new ExpenseRepository();
        } catch (IllegalStateException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        View formCard = findViewById(R.id.card3d);
        Ui3DHelper.applyScreenEntrance(formCard);

        backBtn = findViewById(R.id.backBtn);
        category = findViewById(R.id.category);
        note = findViewById(R.id.note);
        amount = findViewById(R.id.amount);
        addBtn = findViewById(R.id.addBtn);
        recyclerView = findViewById(R.id.recyclerView);
        expenseCountText = findViewById(R.id.expenseCountText);
        listTotalText = findViewById(R.id.listTotalText);
        historyCountBadge = findViewById(R.id.historyCountBadge);
        emptyStateLayout = findViewById(R.id.emptyStateLayout);
        historyCard = findViewById(R.id.historyCard);

        list = new ArrayList<>();
        adapter = new ExpenseAdapter(list);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setAutoMeasureEnabled(true);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(false);
        recyclerView.setNestedScrollingEnabled(false);

        backBtn.setOnClickListener(v -> {
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });

        Ui3DHelper.applyButtonPress3D(addBtn);
        addBtn.setOnClickListener(v -> saveExpense());

        if (getIntent().getBooleanExtra(EXTRA_FOCUS_HISTORY, false)) {
            scrollToHistory();
        }

        updateListSummary();
    }

    private void scrollToHistory() {
        NestedScrollView scrollView = findViewById(R.id.expenseScrollView);
        scrollView.post(() ->
                scrollView.smoothScrollTo(0, historyCard.getTop()));
    }

    private void saveExpense() {
        String cat = category.getText().toString().trim();
        String nt = note.getText().toString().trim();
        String amt = amount.getText().toString().trim();

        if (cat.isEmpty() || amt.isEmpty()) {
            Toast.makeText(this, "Category and amount are required", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double value = Double.parseDouble(amt);
            if (value <= 0) {
                Toast.makeText(this, "Amount must be greater than 0", Toast.LENGTH_SHORT).show();
                return;
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter a valid amount", Toast.LENGTH_SHORT).show();
            return;
        }

        addBtn.setEnabled(false);

        ExpenseModel model = new ExpenseModel(cat, nt, amt);
        final String savedDateTime = ExpenseDateFormatter.formatDateTime(model.getCreatedAt());

        repository.addExpense(model, new ExpenseRepository.SaveListener() {
            @Override
            public void onSuccess() {
                addBtn.setEnabled(true);
                category.setText("");
                note.setText("");
                amount.setText("");
                category.requestFocus();
                Toast.makeText(AddExpenseActivity.this,
                        getString(R.string.expense_saved_with_date, savedDateTime),
                        Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(String message) {
                addBtn.setEnabled(true);
                Toast.makeText(AddExpenseActivity.this,
                        "Save failed: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        loadExpensesFromDatabase();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (repository != null) {
            repository.removeExpenseListListener();
        }
    }

    private void loadExpensesFromDatabase() {
        repository.listenForExpenseList(new ExpenseRepository.ExpenseListListener() {
            @Override
            public void onExpensesLoaded(List<ExpenseModel> expenses) {
                list.clear();
                idToIndex.clear();
                list.addAll(expenses);
                for (int i = 0; i < list.size(); i++) {
                    ExpenseModel expense = list.get(i);
                    if (expense.getId() != null) {
                        idToIndex.put(expense.getId(), i);
                    }
                }
                adapter.notifyDataSetChanged();
                updateListSummary();
            }

            @Override
            public void onLoadFailed(String message) {
                Toast.makeText(AddExpenseActivity.this,
                        "Could not load expenses: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void updateListSummary() {
        int count = list.size();
        expenseCountText.setText(String.valueOf(count));
        historyCountBadge.setText(count + (count == 1 ? " item" : " items"));

        double total = 0;
        for (ExpenseModel expense : list) {
            if (expense.getAmount() != null) {
                try {
                    total += Double.parseDouble(expense.getAmount().trim());
                } catch (NumberFormatException ignored) {
                }
            }
        }

        listTotalText.setText(formatCurrency(total));

        boolean isEmpty = list.isEmpty();
        emptyStateLayout.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        recyclerView.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
        historyCard.setVisibility(View.VISIBLE);
    }

    private String formatCurrency(double amount) {
        String formatted = amount == Math.floor(amount)
                ? currencyFormat.format((long) amount)
                : currencyFormat.format(amount);
        return getString(R.string.currency_prefix) + " " + formatted;
    }
}
