package com.example.smartexpensetracker;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ExpenseDateFormatter {

    private static final SimpleDateFormat DATE_TIME_FORMAT =
            new SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault());

    private ExpenseDateFormatter() {
    }

    public static String formatDateTime(long timestamp) {
        if (timestamp <= 0L) {
            return "";
        }
        return DATE_TIME_FORMAT.format(new Date(timestamp));
    }
}
