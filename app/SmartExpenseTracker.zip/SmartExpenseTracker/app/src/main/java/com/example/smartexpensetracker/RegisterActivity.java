package com.example.smartexpensetracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {

    EditText email, password;
    FirebaseAuth auth;
    Button registerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        View card = findViewById(R.id.card3d);
        Ui3DHelper.applyScreenEntrance(card);

        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        registerBtn = findViewById(R.id.registerBtn);

        auth = FirebaseAuth.getInstance();

        Ui3DHelper.applyButtonPress3D(registerBtn);

        registerBtn.setOnClickListener(v -> {
            String userEmail = email.getText().toString().trim();
            String userPassword = password.getText().toString().trim();

            if (userEmail.isEmpty() || userPassword.isEmpty()) {
                Toast.makeText(this, "Email and Password required", Toast.LENGTH_SHORT).show();
                return;
            }

            auth.createUserWithEmailAndPassword(userEmail, userPassword)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(this, "Registration Successful", Toast.LENGTH_SHORT).show();
                            AuthNavigator.openDashboard(RegisterActivity.this);
                        } else {
                            String message = task.getException() != null
                                    ? task.getException().getMessage()
                                    : "Registration failed";
                            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }
}
