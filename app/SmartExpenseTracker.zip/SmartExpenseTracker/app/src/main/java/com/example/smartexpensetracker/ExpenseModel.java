package com.example.smartexpensetracker;

public class ExpenseModel {

    private String id;
    private String category;
    private String note;
    private String amount;
    private long createdAt;

    public ExpenseModel() {
    }

    public ExpenseModel(String category, String note, String amount) {
        this.category = category;
        this.note = note;
        this.amount = amount;
        this.createdAt = System.currentTimeMillis();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }
}
