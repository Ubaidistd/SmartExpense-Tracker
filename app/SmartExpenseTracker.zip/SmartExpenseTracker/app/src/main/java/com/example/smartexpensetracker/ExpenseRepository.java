package com.example.smartexpensetracker;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ExpenseRepository {

    public interface ExpenseChangeListener {
        void onExpenseAdded(ExpenseModel expense);

        void onExpenseChanged(ExpenseModel expense);

        void onExpenseRemoved(String expenseId);

        void onLoadFailed(String message);
    }

    public interface TotalListener {
        void onTotalCalculated(double total);

        void onLoadFailed(String message);
    }

    public interface SalaryListener {
        void onSalaryLoaded(double salary);

        void onLoadFailed(String message);
    }

    public interface SaveListener {
        void onSuccess();

        void onFailure(String message);
    }

    public interface ExpenseListListener {
        void onExpensesLoaded(List<ExpenseModel> expenses);

        void onLoadFailed(String message);
    }

    private final DatabaseReference expensesRef;
    private final DatabaseReference profileRef;

    @Nullable
    private ChildEventListener childEventListener;

    @Nullable
    private ValueEventListener totalEventListener;

    @Nullable
    private ValueEventListener salaryEventListener;

    @Nullable
    private ValueEventListener expenseListEventListener;

    public ExpenseRepository() throws IllegalStateException {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) {
            throw new IllegalStateException("User not logged in");
        }

        DatabaseReference userRef = FirebaseDatabase.getInstance()
                .getReference("users")
                .child(user.getUid());

        expensesRef = userRef.child("expenses");
        profileRef = userRef.child("profile");
    }

    public void saveMonthlySalary(double salary, SaveListener listener) {
        profileRef.child("monthlySalary").setValue(salary)
                .addOnSuccessListener(unused -> listener.onSuccess())
                .addOnFailureListener(e -> listener.onFailure(
                        e.getMessage() != null ? e.getMessage() : "Could not save salary"));
    }

    public void listenForSalary(SalaryListener listener) {
        removeSalaryListener();

        salaryEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Double value = snapshot.getValue(Double.class);
                listener.onSalaryLoaded(value != null ? value : 0);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.onLoadFailed(error.getMessage());
            }
        };

        profileRef.child("monthlySalary").addValueEventListener(salaryEventListener);
    }

    public void addExpense(ExpenseModel expense, SaveListener listener) {
        String key = expensesRef.push().getKey();
        if (key == null) {
            listener.onFailure("Could not create expense id");
            return;
        }

        expense.setId(key);
        if (expense.getCreatedAt() == 0L) {
            expense.setCreatedAt(System.currentTimeMillis());
        }

        expensesRef.child(key).setValue(expense)
                .addOnSuccessListener(unused -> listener.onSuccess())
                .addOnFailureListener(e -> listener.onFailure(
                        e.getMessage() != null ? e.getMessage() : "Save failed"));
    }

    public void listenForChanges(ExpenseChangeListener listener) {
        removeExpenseListener();

        childEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                ExpenseModel expense = snapshot.getValue(ExpenseModel.class);
                if (expense != null) {
                    expense.setId(snapshot.getKey());
                    listener.onExpenseAdded(expense);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                ExpenseModel expense = snapshot.getValue(ExpenseModel.class);
                if (expense != null) {
                    expense.setId(snapshot.getKey());
                    listener.onExpenseChanged(expense);
                }
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
                listener.onExpenseRemoved(snapshot.getKey());
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.onLoadFailed(error.getMessage());
            }
        };

        expensesRef.addChildEventListener(childEventListener);
    }

    public void listenForExpenseList(ExpenseListListener listener) {
        removeExpenseListListener();

        expenseListEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<ExpenseModel> expenses = new ArrayList<>();
                for (DataSnapshot child : snapshot.getChildren()) {
                    ExpenseModel expense = child.getValue(ExpenseModel.class);
                    if (expense != null) {
                        expense.setId(child.getKey());
                        if (expense.getCreatedAt() == 0L) {
                            expense.setCreatedAt(child.child("createdAt").getValue(Long.class) != null
                                    ? child.child("createdAt").getValue(Long.class) : 0L);
                        }
                        expenses.add(expense);
                    }
                }
                Collections.sort(expenses, (a, b) ->
                        Long.compare(b.getCreatedAt(), a.getCreatedAt()));
                listener.onExpensesLoaded(expenses);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.onLoadFailed(error.getMessage());
            }
        };

        expensesRef.addValueEventListener(expenseListEventListener);
    }

    public void listenForTotal(TotalListener listener) {
        removeTotalListener();

        totalEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                double total = 0;
                for (DataSnapshot child : snapshot.getChildren()) {
                    ExpenseModel expense = child.getValue(ExpenseModel.class);
                    if (expense != null && expense.getAmount() != null) {
                        try {
                            total += Double.parseDouble(expense.getAmount().trim());
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
                listener.onTotalCalculated(total);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                listener.onLoadFailed(error.getMessage());
            }
        };

        expensesRef.addValueEventListener(totalEventListener);
    }

    public void removeExpenseListener() {
        if (childEventListener != null) {
            expensesRef.removeEventListener(childEventListener);
            childEventListener = null;
        }
    }

    public void removeTotalListener() {
        if (totalEventListener != null) {
            expensesRef.removeEventListener(totalEventListener);
            totalEventListener = null;
        }
    }

    public void removeSalaryListener() {
        if (salaryEventListener != null) {
            profileRef.child("monthlySalary").removeEventListener(salaryEventListener);
            salaryEventListener = null;
        }
    }

    public void removeExpenseListListener() {
        if (expenseListEventListener != null) {
            expensesRef.removeEventListener(expenseListEventListener);
            expenseListEventListener = null;
        }
    }

    public void removeAllListeners() {
        removeExpenseListener();
        removeExpenseListListener();
        removeTotalListener();
        removeSalaryListener();
    }
}
