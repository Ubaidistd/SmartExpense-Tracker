package com.example.smartexpensetracker;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

import androidx.recyclerview.widget.RecyclerView;

public final class Ui3DHelper {

    private Ui3DHelper() {
    }

    public static void applyScreenEntrance(View card) {
        if (card == null) {
            return;
        }

        float density = card.getResources().getDisplayMetrics().density;
        card.setCameraDistance(12000f * density);
        card.setRotationX(22f);
        card.setAlpha(0f);
        card.setTranslationY(120f);
        card.setScaleX(0.9f);
        card.setScaleY(0.9f);

        card.animate()
                .rotationX(0f)
                .alpha(1f)
                .translationY(0f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(750)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    public static void applyFloatAnimation(View view) {
        if (view == null) {
            return;
        }

        ObjectAnimator animator = ObjectAnimator.ofFloat(view, View.TRANSLATION_Y, 0f, -18f, 0f);
        animator.setDuration(2400);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.start();
    }

    public static void applyButtonPress3D(View button) {
        if (button == null) {
            return;
        }

        button.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate()
                            .scaleX(0.94f)
                            .scaleY(0.94f)
                            .rotationX(6f)
                            .translationZ(-6f)
                            .setDuration(90)
                            .start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .rotationX(0f)
                            .translationZ(12f)
                            .setDuration(120)
                            .start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    public static void applyListItemEntrance(View itemView, int position) {
        if (itemView == null) {
            return;
        }

        float density = itemView.getResources().getDisplayMetrics().density;
        itemView.setCameraDistance(8000f * density);
        itemView.setRotationX(14f);
        itemView.setAlpha(0f);
        itemView.setTranslationX(40f);

        itemView.animate()
                .rotationX(0f)
                .alpha(1f)
                .translationX(0f)
                .setStartDelay(position * 60L)
                .setDuration(450)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }

    public static void applyRecyclerDepth(RecyclerView recyclerView) {
        if (recyclerView == null) {
            return;
        }

        float density = recyclerView.getResources().getDisplayMetrics().density;
        recyclerView.setCameraDistance(10000f * density);
        recyclerView.setRotationX(4f);

        recyclerView.animate()
                .rotationX(0f)
                .setDuration(600)
                .setInterpolator(new DecelerateInterpolator())
                .start();
    }
}
