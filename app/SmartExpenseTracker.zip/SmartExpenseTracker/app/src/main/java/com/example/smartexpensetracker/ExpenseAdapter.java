package com.example.smartexpensetracker;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class ExpenseAdapter extends RecyclerView.Adapter<ExpenseAdapter.ViewHolder> {

    private final ArrayList<ExpenseModel> list;
    private final NumberFormat currencyFormat = NumberFormat.getNumberInstance(Locale.US);

    public ExpenseAdapter(ArrayList<ExpenseModel> list) {
        this.list = list;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        TextView category, note, amount, dateTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            category = itemView.findViewById(R.id.categoryText);
            note = itemView.findViewById(R.id.noteText);
            amount = itemView.findViewById(R.id.amountText);
            dateTime = itemView.findViewById(R.id.dateTimeText);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.expense_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ExpenseModel model = list.get(position);

        holder.category.setText(model.getCategory());

        String dateTimeText = ExpenseDateFormatter.formatDateTime(model.getCreatedAt());
        if (TextUtils.isEmpty(dateTimeText)) {
            holder.dateTime.setVisibility(View.GONE);
        } else {
            holder.dateTime.setVisibility(View.VISIBLE);
            holder.dateTime.setText(dateTimeText);
        }

        String noteText = model.getNote();
        if (TextUtils.isEmpty(noteText)) {
            holder.note.setVisibility(View.GONE);
        } else {
            holder.note.setVisibility(View.VISIBLE);
            holder.note.setText(noteText);
        }

        holder.amount.setText(formatAmount(holder.itemView, model.getAmount()));
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    private String formatAmount(View view, String amountStr) {
        if (amountStr == null || amountStr.trim().isEmpty()) {
            return view.getContext().getString(R.string.currency_prefix) + " 0";
        }
        try {
            double amount = Double.parseDouble(amountStr.trim());
            String formatted = amount == Math.floor(amount)
                    ? currencyFormat.format((long) amount)
                    : currencyFormat.format(amount);
            return view.getContext().getString(R.string.currency_prefix) + " " + formatted;
        } catch (NumberFormatException e) {
            return view.getContext().getString(R.string.currency_prefix) + " " + amountStr;
        }
    }
}
